# Project Documentation: Virtual Network Lab — VLAN Switching, Routing & Network Automation

**Project date:** January 2026  
**Domain:** Networking  
**Purpose of this document:** Detailed technical explanation of the lab, suitable for repository documentation, project demonstrations, and interview preparation.

> **Implementation boundary:** The lab described here uses Linux network namespaces, virtual Ethernet interfaces, Linux bridges, `dnsmasq`, `iptables`, and diagnostic tools. Juniper/Junos references are learning mappings only. Do not present the Linux lab as if it was configured on Juniper hardware.

---

## 1. Project summary

The Virtual Network Lab models a small enterprise network in software. It demonstrates how virtual hosts can be connected through virtual switches, separated into VLANs, and allowed to communicate across IP subnets through a virtual router.

The lab also includes DHCP service, traffic filtering, network diagnostics, packet inspection, and a command-line interface for common network setup and testing operations.

The project focuses on understanding not only how to configure a network, but also how to verify the configuration and investigate failures.

## 2. Problem statement

Physical networking labs require switches, routers, cables, and endpoint devices. They can be expensive or difficult to reproduce consistently. A virtual lab provides a practical way to experiment with network concepts on a Linux machine.

The project addresses the following learning goals:

1. Represent hosts and network components virtually.
2. Connect components using virtual links.
3. implement Layer 2 switching and VLAN segmentation.
4. Carry multiple VLANs across trunk links.
5. Route traffic between separate IPv4 networks.
6. Assign client addresses automatically.
7. Apply traffic-filtering rules.
8. Test connectivity and inspect network state.
9. Reduce repetitive setup through a command-line interface.

## 3. Addressing plan

The two principal IPv4 networks are:

| Property | VLAN 10 | VLAN 20 |
|---|---|---|
| VLAN ID | 10 | 20 |
| IPv4 subnet | `192.168.10.0/24` | `192.168.20.0/24` |
| Subnet mask | `255.255.255.0` | `255.255.255.0` |
| Router gateway | `192.168.10.1` | `192.168.20.1` |
| Example client | `192.168.10.111` | `192.168.20.190` |

These example client addresses were observed in the lab. DHCP assignments can vary depending on the current DHCP configuration and lease state.

A `/24` subnet has 256 total IPv4 addresses, of which 254 are ordinarily usable as host addresses in a conventional IPv4 subnet. The network and broadcast addresses are not assigned to ordinary hosts.

## 4. Architecture and components

### 4.1 Network namespaces

A network namespace isolates network interfaces, routing tables, and related networking state. Namespaces let the lab simulate separate hosts or network components on a single Linux machine.

Each simulated endpoint can have its own interfaces, IP addresses, routes, and neighbor entries.

### 4.2 Virtual Ethernet (`veth`) pairs

A `veth` pair provides two connected virtual Ethernet interfaces. Traffic transmitted through one end can be received at the other end. One end can be placed in a namespace while the other is attached to a bridge or another namespace.

This is the virtual equivalent of a cable between two interfaces.

### 4.3 Linux bridges

A Linux bridge forwards Ethernet frames between connected interfaces. With VLAN filtering configured, bridge ports can be associated with VLAN IDs and can enforce VLAN membership.

In this lab, bridges provide the switching behavior needed to connect virtual PCs and other virtual network components.

### 4.4 Virtual router

The router provides Layer 3 forwarding between the two IPv4 subnets. The VLAN 10 gateway is `192.168.10.1`, and the VLAN 20 gateway is `192.168.20.1`.

The router's routing table included directly connected routes for both networks. These routes allow it to determine that the two subnets are reachable through their respective VLAN interfaces.

### 4.5 DHCP service

`dnsmasq` provides DHCP service for client address allocation. A DHCP server can provide an IP address and other settings such as the subnet mask, default gateway, and DNS server, depending on the configured pool and options.

### 4.6 Traffic filtering

`iptables` configures Linux packet-filtering rules. The rules can be used to allow or deny selected traffic. The exact effect depends on the rule conditions, chain, direction, connection state, and packet path.

### 4.7 Command-line interface

The project provides a CLI with operations such as creating PCs and switches, connecting devices, assigning VLANs, configuring IP addresses, creating trunks, testing connectivity, and showing network status.

The CLI acts as a user-facing control layer. The backend performs the requested network operations. Exact implementation details should be described from the actual source code; this document does not assume unverified behavior such as automatic deletion cleanup.

### 4.8 Packet inspection

Wireshark can inspect packets captured at a suitable interface or from a saved capture. The project included inspection of a capture intended to examine VLAN trunk traffic. Whether 802.1Q tags are visible depends on the capture location, interface behavior, and offload settings.

## 5. VLAN segmentation

A VLAN is a logical Layer 2 broadcast domain. Devices in different VLANs are separated at Layer 2 even if they are connected through the same physical or virtual switching infrastructure.

In this project:

- VLAN 10 carries traffic for `192.168.10.0/24`.
- VLAN 20 carries traffic for `192.168.20.0/24`.

The VLANs are associated with separate IP subnets. This is a common design, although a VLAN and an IP subnet are different concepts.

### Benefits

- Separates broadcast domains.
- Supports logical network organization.
- Reduces unnecessary broadcast propagation between groups.
- Provides a foundation for access-control design when combined with routing policies and filtering.

VLANs alone should not be treated as a complete security boundary. Traffic routed between VLANs may require firewall filters or security policies.

## 6. Access ports and trunk links

### 6.1 Access ports

An access port is normally assigned to one data VLAN and commonly connects to an endpoint such as a PC. The endpoint usually sends and receives untagged Ethernet frames. The switch associates those frames with the port's configured VLAN.

### 6.2 Trunk links

A trunk can carry traffic from multiple VLANs over one link. IEEE 802.1Q tagging identifies the VLAN of tagged Ethernet frames.

A simplified frame flow for VLAN 10 is:

1. A PC sends an untagged Ethernet frame into its access port.
2. The switch associates the frame with VLAN 10.
3. When the frame is forwarded over a trunk, the switch normally tags it with VLAN 10.
4. The receiving switch processes the frame as VLAN 10 traffic.
5. The receiving switch forwards it toward the destination port in that VLAN.

Native or untagged VLAN behavior depends on the trunk configuration.

## 7. Inter-VLAN routing

VLAN 10 and VLAN 20 are separate IP subnets. A Layer 2 switch does not route packets between those subnets simply because both VLANs exist on the switch.

The virtual router provides Layer 3 connectivity between them.

### Example packet flow: VLAN 10 to VLAN 20

Assume PC6 has address `192.168.10.111` and PC8 has address `192.168.20.190`.

1. PC6 checks the destination address against its local subnet.
2. Since PC8 is outside `192.168.10.0/24`, PC6 sends the packet to its default gateway, `192.168.10.1`.
3. The packet crosses the VLAN 10 switching path to the router.
4. The router checks its routing information and selects the VLAN 20 path.
5. The router forwards the packet toward PC8, assuming no filtering rule blocks it.
6. PC8 receives the packet and can send a reply through its default gateway, `192.168.20.1`.

### What changes when a router forwards a packet?

In ordinary routing without NAT, the source and destination IP addresses generally remain unchanged. The Layer 2 Ethernet header is rebuilt for the next link, so source and destination MAC addresses change. The IPv4 TTL decreases by one at each router hop.

## 8. DHCP and dnsmasq

DHCP (Dynamic Host Configuration Protocol) automates the assignment of IP configuration to clients.

The common DHCP exchange is known as DORA:

1. **Discover:** The client searches for a DHCP server.
2. **Offer:** A server offers an address and configuration.
3. **Request:** The client requests the offered address.
4. **Acknowledge:** The server confirms the lease.

In the initial IPv4 DHCP exchange, Discover and Request commonly use source IP `0.0.0.0` and destination IP `255.255.255.255`. Offer and Acknowledge delivery can be broadcast or unicast depending on the client's state and server behavior. DHCP uses UDP port 67 on the server side and UDP port 68 on the client side.

`dnsmasq` is a lightweight service that can provide DHCP and DNS-related functionality. In this project, it was used for DHCP service.

If a DHCP server is on a different subnet from clients, a DHCP relay may be required. The exact setup depends on the network topology and DHCP configuration.

## 9. Traffic filtering and firewall isolation

`iptables` configures Linux packet-filtering rules. Depending on the rules, traffic can be permitted or dropped based on addresses, protocols, ports, interfaces, and connection state.

The difference between the main concepts is:

- **VLAN:** separates Layer 2 broadcast domains.
- **Routing:** determines how traffic can be forwarded between IP networks.
- **Firewall filtering:** allows or denies traffic that matches a policy.

For example, a router may have a route between VLAN 10 and VLAN 20, but a firewall rule can still block selected traffic between them.

A successful ping shows that the tested ICMP exchange was permitted at that time. It does not establish that all protocols or all traffic directions are allowed.

## 10. CLI workflow and automation

The command-line interface makes common network operations available through menu options. The reported options include:

- Create switch.
- Create PC.
- Connect devices.
- Assign VLAN.
- Configure IP address.
- Create trunk.
- Ping PC.
- Show network status.

### Example workflow

1. Create the virtual switches.
2. Create virtual PCs.
3. Connect PCs and switches using virtual links.
4. Assign endpoint ports to the appropriate VLANs.
5. Configure trunk links between switches.
6. Configure router gateway interfaces.
7. Configure DHCP and traffic-filtering rules.
8. Run connectivity tests and inspect network state.

### What happens when adding a PC?

At a conceptual level, the backend creates a namespace representing the PC and prepares its virtual interface. The interface is connected to the virtual switching topology through a virtual Ethernet link. The host can then receive IP configuration manually or through DHCP.

### What happens when creating a switch?

The backend creates a Linux bridge to provide Layer 2 switching and allows interfaces to be attached to it.

### What happens when connecting devices?

The backend creates or configures the virtual link and attaches the relevant interfaces to the selected components.

### What happens when assigning a VLAN?

The backend configures the relevant bridge-port VLAN membership so traffic is associated with the intended VLAN.

### What happens when creating a trunk?

The backend configures a link to carry the required VLANs, including the relevant VLAN tagging behavior.

### Deletion and cleanup

Deleting a virtual device generally requires removing its namespace or bridge and cleaning up related virtual interfaces and links. Do not claim a deletion feature exists unless the current implementation actually provides and tests it.

### Why automate?

Automation reduces repetitive manual setup and makes it easier to repeat a network configuration and its tests. The CLI provides a consistent way to request common operations, while the backend applies the relevant network configuration.

## 11. Testing and validation

The lab uses multiple checks because no single diagnostic proves that every part of a network is correct.

| Check | What it tells you |
|---|---|
| Ping | Whether the destination responds to ICMP Echo traffic |
| Route table | Which routes are available in the current network namespace |
| Neighbor/ARP table | Whether local IP-to-MAC resolution information is available |
| Bridge VLAN output | Which VLANs are associated with bridge ports |
| Tracepath | Information about the path and path MTU |
| Wireshark | Packet details visible at the capture point |

### Recorded test observations

The following observations were recorded during the project:

- PC3 to PC5 in VLAN 10: 3 packets transmitted, 3 received, 0% packet loss, TTL 64.
- PC6 to PC8 across VLANs: 3 packets transmitted, 3 received, 0% packet loss, TTL 63.
- The router had directly connected routes for `192.168.10.0/24` and `192.168.20.0/24`.
- Bridge VLAN output showed access ports assigned to VLAN 10 or VLAN 20 and trunk links carrying VLANs 10 and 20.

These are recorded observations, not a guarantee that the same results will appear in every environment. Re-run the tests after rebuilding the lab.

A TTL change from 64 to 63 is consistent with one router hop when the initial TTL is 64, but it is not conclusive evidence of the entire path.

## 12. Understanding tracepath

`tracepath` is a diagnostic utility that investigates the path toward a destination and can provide path-MTU information.

It is useful alongside ping and route inspection:

- Ping checks basic IP reachability.
- Route inspection shows locally known forwarding routes.
- Tracepath may reveal path information and MTU-related behavior.
- Packet capture can show packets and responses visible at the capture point.

Tracepath output depends on the network and whether intermediate devices return the expected diagnostic messages. Do not claim it identified a particular failing hop unless the actual output supports that conclusion.

## 13. Troubleshooting methodology

When a PC cannot reach a destination, use a layered approach:

1. **Link/interface:** Are the interfaces up and connected?
2. **IP configuration:** Are IP address, subnet mask, and gateway correct?
3. **VLAN:** Is the endpoint port assigned to the correct VLAN?
4. **Trunk:** Does the trunk carry the required VLAN?
5. **Local resolution:** Is the destination or gateway MAC address resolved where needed?
6. **Routing:** Does the router have a route to the destination network?
7. **Filtering:** Are firewall rules dropping the traffic?
8. **Testing:** Use ping, tracepath, route inspection, and packet capture to isolate the failure.

### Example: same-VLAN communication fails

Check endpoint IP configuration, interface state, bridge connection, VLAN membership, and ARP resolution.

### Example: inter-VLAN communication fails

Check the source default gateway, trunk VLAN membership, router logical interfaces, routing table, return route, and firewall policy.

### Example: DHCP fails

Check the client link and VLAN, DHCP service state, configured address pool, DHCP server reachability, and relay configuration if the server is on another subnet.

## 14. Mapping the concepts to Juniper Junos

This project was implemented in Linux. The following table maps the concepts to related Juniper learning topics; it does not imply that Juniper hardware was used.

| Project concept | Related Junos concept |
|---|---|
| VLAN membership | VLAN definition and interface VLAN membership |
| Access port | Ethernet switching interface in access mode |
| Trunk link | Ethernet switching interface in trunk mode |
| Router-on-a-stick | VLAN-tagged logical interfaces on supported routers |
| VLAN gateway on a Layer 3 switch | IRB interface, depending on platform design |
| Interface status | `show interfaces terse` |
| VLAN state | `show vlans` |
| Switching-port state | `show ethernet-switching interfaces` |
| Routing table | `show route` |
| ARP table | `show arp` |
| Reachability test | `ping <destination-ip>` |
| Path diagnostic | `traceroute <destination-ip>` |

Junos command syntax differs across platforms, Junos versions, and configuration styles. Confirm syntax for the target device before applying commands.

## 15. Limitations

- This is a virtual learning lab, not a production network.
- Results depend on the current Linux networking configuration.
- Tracepath and packet-capture results depend on the path and capture point.
- Successful ping tests only establish reachability for the tested ICMP exchange.
- Firewall behavior should be documented based on the actual rules and tests.
- Automation claims should match the operations implemented in the current source code.
- Deletion, rollback, and cleanup behavior should not be claimed unless verified.

## 16. Learning outcomes

The project provided practical experience with:

- Network namespaces and virtual interfaces.
- Layer 2 switching and VLAN segmentation.
- Access ports and 802.1Q trunk links.
- Inter-VLAN routing and default gateways.
- DHCP and automatic IP configuration.
- Traffic filtering and firewall isolation.
- CLI-driven network setup.
- Connectivity testing and systematic troubleshooting.
- Packet inspection and the relationship between configuration and observed traffic.

## 17. Suggested interview summary

“My project was a Virtual Network Lab for VLAN Switching, Routing, and Network Automation. I used Linux network namespaces to simulate hosts and network components, virtual Ethernet links to connect them, and Linux bridges for Layer 2 switching. I created VLAN 10 and VLAN 20, configured access ports and 802.1Q trunk links, and used a virtual router to enable inter-VLAN routing. I used dnsmasq for DHCP and iptables for traffic filtering. A command-line interface exposed common operations such as creating virtual devices, connecting them, assigning VLANs, and testing connectivity. I validated the network using ping, routing and neighbor-table inspection, tracepath, and packet captures. The project helped me understand switching, routing, segmentation, and troubleshooting, and I am applying those concepts to learning Juniper Junos.”

---

## Before publishing

Review the repository and make sure:

- The commands and menu options match the current code.
- The topology image, if added, matches the actual lab.
- Test results are labelled as recorded results and can be reproduced.
- Firewall claims match the actual rules.
- Any delete/cleanup feature is documented only if implemented.
- Juniper examples are clearly labelled as learning mappings, not the Linux implementation.
